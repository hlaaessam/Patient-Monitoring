package org.codeforiraq.patientmonitoring;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PatientCalenderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_calender);

        // page title
        getSupportActionBar().setTitle("Calender");

        // to show back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}