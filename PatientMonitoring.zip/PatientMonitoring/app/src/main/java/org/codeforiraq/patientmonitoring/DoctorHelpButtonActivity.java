package org.codeforiraq.patientmonitoring;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DoctorHelpButtonActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_help_button);

        // page title
        getSupportActionBar().setTitle("Help");

        // to show back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }
}