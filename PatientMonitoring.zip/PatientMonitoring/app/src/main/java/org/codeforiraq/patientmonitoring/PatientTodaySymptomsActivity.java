package org.codeforiraq.patientmonitoring;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PatientTodaySymptomsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_today_symptoms);

        // page title
        getSupportActionBar().setTitle("today symptoms");

        // to show back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}