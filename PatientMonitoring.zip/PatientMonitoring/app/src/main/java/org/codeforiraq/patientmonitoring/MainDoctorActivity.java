package org.codeforiraq.patientmonitoring;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainDoctorActivity extends AppCompatActivity {
    private Button profileButton;
    private Button calenderButton;
    private Button historyButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_doctor);

        // page title
        getSupportActionBar().setTitle("Main Doctor");

        // buttons declaration
        profileButton=findViewById(R.id.profilebutton);
        calenderButton=findViewById(R.id.calenderbutton);
        historyButton=findViewById(R.id.historybutton);

        //move from Main doctor to profile
        profileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainDoctorActivity.this, DoctorprofileActivity.class));
            }
        });

        //move from Main doctor to Calender
        calenderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainDoctorActivity.this, DoctorCalenderActivity.class));
            }
        });
        //move from Main doctor to History
        historyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainDoctorActivity.this, DoctorHistoryActivity.class));
            }
        });

    }
}