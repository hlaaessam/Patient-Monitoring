package org.codeforiraq.patientmonitoring;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DoctorCalenderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_calender);
        // page title
        getSupportActionBar().setTitle("Calender");

        // to show back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}