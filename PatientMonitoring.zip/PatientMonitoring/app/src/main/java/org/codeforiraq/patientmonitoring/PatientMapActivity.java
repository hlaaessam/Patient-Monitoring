package org.codeforiraq.patientmonitoring;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PatientMapActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_map);

        // page title
        getSupportActionBar().setTitle("Map");

        // to show back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}